#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    int tahmin, hedef, denemeSayisi, kalanHak;
    char tekrar;

    do {
        srand(time(0));
        hedef = rand() % 100 + 1;
        kalanHak = 5;
        denemeSayisi = 0;

        printf("\n1 ile 100 arasinda bir sayi tuttum. Bakalim bulabilecek misin?\n");
        printf("5 deneme hakkiniz var.\n");

        do {
            printf("\nKalan hakkiniz: %d\n", kalanHak);
            printf("Tahmininizi girin: ");
            scanf("%d", &tahmin);
            denemeSayisi++;
            kalanHak--;

            if (tahmin == hedef) {
                printf("Tebrikler! %d tahminde dogru bildiniz.\n", denemeSayisi);
                break;
            } else if (abs(tahmin - hedef) <= 5) {
                printf("Cok yakin!\n");
            }

            if (tahmin < hedef) {
                printf("Daha buyuk bir sayi tahmin edin!\n");
            } else if (tahmin > hedef) {
                printf("Daha kucuk bir sayi tahmin edin!\n");
            }
        } while (kalanHak > 0);

        if (kalanHak == 0 && tahmin != hedef) {
            printf("\nMaalesef! Tahmin hakkiniz bitti. Tuttugum sayi %d idi.\n", hedef);
        }

        printf("\nTekrar denemek ister misiniz? (Evet icin 'e', Hayir icin 'h' girin): ");
        scanf(" %c", &tekrar);

    } while (tekrar == 'e' || tekrar == 'E');

    printf("\nOyun bitti. Oynadiginiz icin tesekkurler!\n");

    return 0;
}